const person = {
  first: 'Ajit',
  last: 'Mandal'
}

export { person }
